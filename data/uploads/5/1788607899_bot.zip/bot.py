import asyncio
import html
import logging
import os
import sys
from typing import Any, Optional

if sys.platform == "win32":
    try:
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8")
        if hasattr(sys.stderr, "reconfigure"):
            sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass


from aiogram import Bot, Dispatcher, F
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BotCommand,
    CallbackQuery,
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from dotenv import load_dotenv

from config import config_manager
from database import get_all_user_ids, get_user_count, init_db, register_user
from keyboards import (
    build_admin_main_kb,
    build_admins_list_kb,
    build_button_detail_kb,
    build_buttons_list_kb,
    build_cancel_kb,
    build_color_select_kb,
    build_gen_key_kb,
    build_user_keyboard,
    build_voice_settings_kb,
    build_welcome_settings_kb,
    get_style_badge,
)

load_dotenv()

# Logging
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)

# Environment Configuration
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
OWNER_ID_RAW = os.getenv("OWNER_ID", "").strip()
OWNER_ID: Optional[int] = int(OWNER_ID_RAW) if OWNER_ID_RAW.isdigit() else None

dp = Dispatcher(storage=MemoryStorage())


# ==============================================================================
# FSM STATES
# ==============================================================================
class AddButtonStates(StatesGroup):
    waiting_text = State()
    waiting_url = State()
    waiting_style = State()
    waiting_emoji = State()


class EditButtonStates(StatesGroup):
    waiting_text = State()
    waiting_url = State()
    waiting_emoji = State()


class GenKeyStates(StatesGroup):
    waiting_text = State()
    waiting_url = State()
    waiting_msg = State()
    waiting_emoji = State()


class WelcomeStates(StatesGroup):
    waiting_text = State()
    waiting_photo = State()


class VoiceStates(StatesGroup):
    waiting_file = State()
    waiting_caption = State()


class AdminMgrStates(StatesGroup):
    waiting_add_id = State()
    waiting_remove_id = State()


class BroadcastStates(StatesGroup):
    waiting_content = State()


# ==============================================================================
# HELPER FUNCTIONS
# ==============================================================================
def is_admin(user_id: int) -> bool:
    return config_manager.is_admin(user_id, OWNER_ID)


async def send_user_start_message(bot: Bot, chat_id: int, user: Optional[Any] = None):
    """Sends the welcome banner, buttons, and optional voice message to a user."""
    cfg = config_manager.config
    raw_text = cfg.get("welcome_text", "Welcome!")
    
    if user:
        name = html.escape(getattr(user, "first_name", "User"))
        uid = getattr(user, "id", chat_id)
        mention = f'<a href="tg://user?id={uid}">{name}</a>'
    else:
        mention = "User"
        
    text = (
        raw_text.replace("{mention}", mention)
        .replace("(mantion the name)", mention)
        .replace("(mention the name)", mention)
        .replace("{name}", mention)
    )
    keyboard = build_user_keyboard(cfg)

    banner_file_id = cfg.get("banner_file_id")
    banner_photo = cfg.get("banner_photo")

    photo_to_send = banner_file_id or banner_photo
    local_banner = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "banner.png")
    if not photo_to_send and os.path.exists(local_banner):
        photo_to_send = FSInputFile(local_banner)

    sent_msg = False
    if photo_to_send:
        try:
            sent = await bot.send_photo(
                chat_id=chat_id,
                photo=photo_to_send,
                caption=text,
                reply_markup=keyboard,
                parse_mode="HTML",
            )
            sent_msg = True
            if not banner_file_id and sent.photo:
                config_manager.set("banner_file_id", sent.photo[-1].file_id)
        except Exception as e:
            logger.warning(f"Failed to send banner photo in HTML: {e}. Trying fallback.")
            try:
                sent = await bot.send_photo(
                    chat_id=chat_id,
                    photo=photo_to_send,
                    caption=text,
                    reply_markup=keyboard,
                )
                sent_msg = True
            except Exception as e2:
                logger.warning(f"Failed to send banner photo: {e2}. Falling back to text.")

    if not sent_msg:
        try:
            await bot.send_message(chat_id=chat_id, text=text, reply_markup=keyboard, parse_mode="HTML")
        except Exception:
            await bot.send_message(chat_id=chat_id, text=text, reply_markup=keyboard)

    # Optional Voice Note
    if cfg.get("voice_enabled", True):
        voice_file_id = cfg.get("voice_file_id")
        voice_caption = cfg.get("voice_caption", "➡️ 𝐊𝐄𝐘 𝐂𝐇𝐈𝐘𝐄 ? 𝐕𝐎𝐈𝐂𝐄 𝐒𝐔𝐍𝐎")
        voice_to_send = voice_file_id
        local_voice = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "voice.mp3")
        if not voice_to_send and os.path.exists(local_voice):
            voice_to_send = FSInputFile(local_voice)

        if voice_to_send:
            try:
                sent_voice = await bot.send_voice(
                    chat_id=chat_id,
                    voice=voice_to_send,
                    caption=voice_caption,
                )
                if not voice_file_id and sent_voice.voice:
                    config_manager.set("voice_file_id", sent_voice.voice.file_id)
            except Exception as e:
                logger.warning(f"Failed to send voice note: {e}")
        else:
            await bot.send_message(chat_id=chat_id, text=voice_caption)



# ==============================================================================
# PUBLIC / USER HANDLERS
# ==============================================================================
@dp.message(CommandStart())
async def cmd_start(message: Message, bot: Bot):
    user = message.from_user
    if user:
        await register_user(user.id, user.username, user.full_name)
    await send_user_start_message(bot, message.chat.id, user=user)



@dp.callback_query(F.data == "user_gen_key_click")
async def handle_user_gen_key(callback: CallbackQuery):
    cfg = config_manager.get("generate_key_button", {})
    msg = cfg.get("callback_msg", "🔑 Here is your generated key: FREE-KEY-8899\nValid for 24 Hours! Enjoy!")
    await callback.answer(msg, show_alert=True)


@dp.callback_query(F.data.startswith("btn_click:"))
async def handle_user_btn_click(callback: CallbackQuery):
    btn_id = callback.data.split(":")[1]
    await callback.answer(f"Channel #{btn_id} selected! Joining...", show_alert=False)


# ==============================================================================
# /ADMIN PANEL ENTRY & MAIN VIEW
# ==============================================================================
@dp.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext):
    await state.clear()
    user = message.from_user
    if not user or not is_admin(user.id):
        # Exact match to Image 1 screenshot: "❌ Unauthorized!"
        await message.answer("❌ Unauthorized!")
        return

    users_count = await get_user_count()
    channels = config_manager.get_channels()
    active_channels = sum(1 for c in channels if c.get("enabled", True))
    admins = config_manager.get("admins", [])

    text = (
        "⚡ <b>WELCOME TO ADMIN PANEL</b> ⚡\n\n"
        "Here you can customize every button, change colors, set Telegram Premium "
        "custom emojis, edit links, banner photo, voice note, and send broadcasts!\n\n"
        f"📊 <b>Current Stats:</b>\n"
        f"• Total Bot Users: <code>{users_count}</code>\n"
        f"• Channel Buttons: <code>{active_channels} / {len(channels)} active</code>\n"
        f"• Total Admins: <code>{len(admins) + (1 if OWNER_ID else 0)}</code>\n\n"
        "👇 <i>Select an option below to manage:</i>"
    )

    await message.answer(
        text=text,
        reply_markup=build_admin_main_kb(),
        parse_mode="HTML",
    )


@dp.callback_query(F.data == "admin:main")
async def callback_admin_main(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return

    users_count = await get_user_count()
    channels = config_manager.get_channels()
    active_channels = sum(1 for c in channels if c.get("enabled", True))
    admins = config_manager.get("admins", [])

    text = (
        "⚡ <b>WELCOME TO ADMIN PANEL</b> ⚡\n\n"
        f"📊 <b>Current Stats:</b>\n"
        f"• Total Bot Users: <code>{users_count}</code>\n"
        f"• Channel Buttons: <code>{active_channels} / {len(channels)} active</code>\n"
        f"• Total Admins: <code>{len(admins) + (1 if OWNER_ID else 0)}</code>\n\n"
        "👇 <i>Select an option below to manage:</i>"
    )

    if callback.message:
        try:
            await callback.message.edit_text(
                text=text,
                reply_markup=build_admin_main_kb(),
                parse_mode="HTML",
            )
        except Exception:
            await callback.message.answer(
                text=text,
                reply_markup=build_admin_main_kb(),
                parse_mode="HTML",
            )
    await callback.answer()


@dp.callback_query(F.data == "admin:refresh")
async def callback_admin_refresh(callback: CallbackQuery, state: FSMContext):
    await callback_admin_main(callback, state)
    await callback.answer("🔄 Admin Panel Refreshed!")


@dp.callback_query(F.data == "admin:close")
async def callback_admin_close(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    if callback.message:
        await callback.message.delete()
    await callback.answer("Admin Panel Closed.")


@dp.callback_query(F.data == "admin:stats")
async def callback_admin_stats(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return

    users_count = await get_user_count()
    channels = config_manager.get_channels()
    active_channels = sum(1 for c in channels if c.get("enabled", True))
    admins = config_manager.get("admins", [])

    text = (
        "📊 <b>DETAILED BOT STATISTICS</b>\n\n"
        f"👥 <b>Total Registered Users:</b> {users_count}\n"
        f"🔘 <b>Total Channel Buttons:</b> {len(channels)}\n"
        f"✅ <b>Active Buttons:</b> {active_channels}\n"
        f"❌ <b>Disabled Buttons:</b> {len(channels) - active_channels}\n"
        f"👑 <b>Owner ID:</b> <code>{OWNER_ID or 'Not Set'}</code>\n"
        f"🛡️ <b>Extra Admins:</b> {len(admins)}\n\n"
        f"🎙️ <b>Voice Note:</b> {'ENABLED ✅' if config_manager.get('voice_enabled') else 'DISABLED ❌'}\n"
        f"↔️ <b>Layout:</b> {config_manager.get('channels_per_row', 2)} Buttons Per Row\n"
    )
    kb = InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(text="🔙 Back", callback_data="admin:main")]]
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=kb, parse_mode="HTML")
    await callback.answer()


@dp.callback_query(F.data == "admin:preview")
async def callback_admin_preview(callback: CallbackQuery, bot: Bot):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return
    await callback.answer("👁️ Displaying live preview...")
    await send_user_start_message(bot, callback.from_user.id, user=callback.from_user)


# ==============================================================================
# BUTTONS & CHANNELS MANAGEMENT
# ==============================================================================
@dp.callback_query(F.data == "admin:buttons")
async def callback_admin_buttons(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return

    channels = config_manager.get_channels()
    row_count = config_manager.get("channels_per_row", 2)
    text = (
        "🔘 <b>CHANNEL BUTTONS MANAGER</b>\n\n"
        "Click on any button below to edit its name, link, color, or custom emoji.\n"
        "You can also add new buttons or toggle layout (1 or 2 per row).\n\n"
        f"Current Layout: <b>{row_count} Buttons Per Row</b>"
    )
    if callback.message:
        await callback.message.edit_text(
            text=text,
            reply_markup=build_buttons_list_kb(channels, row_count),
            parse_mode="HTML",
        )
    await callback.answer()


@dp.callback_query(F.data == "btn_toggle_layout")
async def callback_toggle_layout(callback: CallbackQuery):
    current = config_manager.get("channels_per_row", 2)
    new_layout = 1 if current == 2 else 2
    config_manager.set("channels_per_row", new_layout)
    channels = config_manager.get_channels()
    text = (
        "🔘 <b>CHANNEL BUTTONS MANAGER</b>\n\n"
        f"Layout updated to: <b>{new_layout} Button(s) Per Row</b>"
    )
    if callback.message:
        await callback.message.edit_text(
            text=text,
            reply_markup=build_buttons_list_kb(channels, new_layout),
            parse_mode="HTML",
        )
    await callback.answer(f"Layout changed to {new_layout} per row!")


async def render_btn_detail(callback: CallbackQuery, cid: int):
    channels = config_manager.get_channels()
    target = next((c for c in channels if c.get("id") == cid), None)
    if not target:
        await callback.answer("Button not found!", show_alert=True)
        return

    style_badge = get_style_badge(target.get("style"))
    status = "Active ✅" if target.get("enabled", True) else "Disabled ❌"
    emoji_id = target.get("icon_custom_emoji_id") or "None (Standard Icon)"

    text = (
        f"⚙️ <b>BUTTON SETTINGS #{cid}</b>\n\n"
        f"• <b>Text/Name:</b> <code>{target.get('text')}</code>\n"
        f"• <b>URL/Link:</b> <code>{target.get('url')}</code>\n"
        f"• <b>Button Color:</b> {style_badge}\n"
        f"• <b>Custom Emoji ID:</b> <code>{emoji_id}</code>\n"
        f"• <b>Status:</b> {status}\n\n"
        "Select what you want to change:"
    )
    if callback.message:
        await callback.message.edit_text(
            text=text,
            reply_markup=build_button_detail_kb(target),
            parse_mode="HTML",
        )


@dp.callback_query(F.data.startswith("btn_edit:"))
async def callback_btn_edit(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return

    cid = int(callback.data.split(":")[1])
    await render_btn_detail(callback, cid)
    await callback.answer()


@dp.callback_query(F.data.startswith("btn_prop:toggle:"))
async def callback_btn_toggle(callback: CallbackQuery):
    cid = int(callback.data.split(":")[2])
    channels = config_manager.get_channels()
    target = next((c for c in channels if c.get("id") == cid), None)
    if target:
        new_state = not target.get("enabled", True)
        config_manager.update_channel(cid, {"enabled": new_state})
        await render_btn_detail(callback, cid)
        await callback.answer("Button visibility toggled!")


@dp.callback_query(F.data.startswith("btn_delete:"))
async def callback_btn_delete(callback: CallbackQuery, state: FSMContext):
    cid = int(callback.data.split(":")[1])
    if config_manager.delete_channel(cid):
        await callback.answer(f"Button #{cid} deleted!", show_alert=True)
    else:
        await callback.answer("Failed to delete button.", show_alert=True)
    await callback_admin_buttons(callback, state)


# --- COLOR / STYLE PICKER ---
@dp.callback_query(F.data.startswith("btn_prop:style:"))
async def callback_btn_pick_style(callback: CallbackQuery):
    cid = callback.data.split(":")[2]
    text = (
        "🎨 <b>SELECT BUTTON COLOR / STYLE</b>\n\n"
        "• 🔴 <b>Danger (Red):</b> Red alert colored button\n"
        "• 🟢 <b>Success (Green):</b> Green highlight colored button\n"
        "• 🔵 <b>Primary (Blue):</b> Blue telegram colored button\n"
        "• ⚪ <b>Default:</b> Standard gray telegram button\n\n"
        "Click a color to apply immediately:"
    )
    if callback.message:
        await callback.message.edit_text(
            text=text,
            reply_markup=build_color_select_kb("btn", cid),
            parse_mode="HTML",
        )
    await callback.answer()


@dp.callback_query(F.data.startswith("set_color:"))
async def callback_apply_color(callback: CallbackQuery):
    parts = callback.data.split(":")
    target_type = parts[1]
    target_id = parts[2]
    color = parts[3]

    style_val = None if color == "default" else color

    if target_type == "btn":
        cid = int(target_id)
        config_manager.update_channel(cid, {"style": style_val})
        await callback.answer(f"Color updated to {color.upper()}!")
        await render_btn_detail(callback, cid)
    elif target_type == "gk":
        gk = config_manager.get("generate_key_button", {})
        gk["style"] = style_val
        config_manager.set("generate_key_button", gk)
        await callback.answer(f"Key button color updated to {color.upper()}!")
        await render_gk_settings(callback)



# --- EDIT BUTTON PROPERTIES (FSM) ---
@dp.callback_query(F.data.startswith("btn_prop:text:"))
async def callback_btn_edit_text(callback: CallbackQuery, state: FSMContext):
    cid = int(callback.data.split(":")[2])
    await state.set_state(EditButtonStates.waiting_text)
    await state.update_data(btn_id=cid)
    text = "✏️ <b>Enter the new Button Text / Name:</b>\n(e.g., <code>🗝 CHANEL 1</code> or <code>👑 VIP CHANNEL</code>)"
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(EditButtonStates.waiting_text)
async def state_save_btn_text(message: Message, state: FSMContext):
    data = await state.get_data()
    cid = data.get("btn_id")
    new_text = message.text.strip()
    config_manager.update_channel(cid, {"text": new_text})
    await state.clear()
    await message.answer(f"✅ Button #{cid} name updated to: <b>{new_text}</b>", parse_mode="HTML")
    channels = config_manager.get_channels()
    row_count = config_manager.get("channels_per_row", 2)
    await message.answer("🔘 <b>Updated Buttons List:</b>", reply_markup=build_buttons_list_kb(channels, row_count), parse_mode="HTML")


@dp.callback_query(F.data.startswith("btn_prop:url:"))
async def callback_btn_edit_url(callback: CallbackQuery, state: FSMContext):
    cid = int(callback.data.split(":")[2])
    await state.set_state(EditButtonStates.waiting_url)
    await state.update_data(btn_id=cid)
    text = "🔗 <b>Send the new URL / Link for this button:</b>\n(e.g., <code>https://t.me/YourChannel</code>)"
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(EditButtonStates.waiting_url)
async def state_save_btn_url(message: Message, state: FSMContext):
    data = await state.get_data()
    cid = data.get("btn_id")
    new_url = message.text.strip()
    if not new_url.startswith("http://") and not new_url.startswith("https://") and not new_url.startswith("tg://"):
        new_url = f"https://{new_url}"
    config_manager.update_channel(cid, {"url": new_url})
    await state.clear()
    await message.answer(f"✅ Button #{cid} link updated to: <code>{new_url}</code>", parse_mode="HTML")
    channels = config_manager.get_channels()
    row_count = config_manager.get("channels_per_row", 2)
    await message.answer("🔘 <b>Updated Buttons List:</b>", reply_markup=build_buttons_list_kb(channels, row_count), parse_mode="HTML")


@dp.callback_query(F.data.startswith("btn_prop:emoji:"))
async def callback_btn_edit_emoji(callback: CallbackQuery, state: FSMContext):
    cid = int(callback.data.split(":")[2])
    await state.set_state(EditButtonStates.waiting_emoji)
    await state.update_data(btn_id=cid)
    text = (
        "⭐ <b>SEND TELEGRAM CUSTOM EMOJI ID</b>\n\n"
        "Telegram Premium bots can display custom emojis inside buttons!\n"
        "Enter the numeric <b>Custom Emoji ID</b> (e.g., <code>5258096772776991776</code>).\n\n"
        "💡 <i>Tip: Send <code>none</code> or <code>remove</code> to remove the custom emoji.</i>"
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(EditButtonStates.waiting_emoji)
async def state_save_btn_emoji(message: Message, state: FSMContext):
    data = await state.get_data()
    cid = data.get("btn_id")
    val = message.text.strip()
    emoji_id = None if val.lower() in ["none", "remove", "0", "no"] else val
    config_manager.update_channel(cid, {"icon_custom_emoji_id": emoji_id})
    await state.clear()
    await message.answer(f"✅ Button #{cid} Custom Emoji ID set to: <code>{emoji_id}</code>", parse_mode="HTML")
    channels = config_manager.get_channels()
    row_count = config_manager.get("channels_per_row", 2)
    await message.answer("🔘 <b>Updated Buttons List:</b>", reply_markup=build_buttons_list_kb(channels, row_count), parse_mode="HTML")


# --- ADD NEW BUTTON (FSM) ---
@dp.callback_query(F.data == "btn_add")
async def callback_btn_add(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return
    await state.set_state(AddButtonStates.waiting_text)
    text = (
        "➕ <b>ADD NEW BUTTON - STEP 1/4</b>\n\n"
        "Please send the <b>Button Name / Text</b>:\n"
        "Example: <code>🗝 CHANEL 8</code> or <code>📢 JOIN DISCUSSION</code>"
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(AddButtonStates.waiting_text)
async def state_add_btn_text(message: Message, state: FSMContext):
    text = message.text.strip()
    await state.update_data(text=text)
    await state.set_state(AddButtonStates.waiting_url)
    await message.answer(
        "➕ <b>STEP 2/4: BUTTON LINK</b>\n\n"
        "Send the URL / Channel link:\n"
        "Example: <code>https://t.me/YourChannel</code>",
        reply_markup=build_cancel_kb(),
        parse_mode="HTML",
    )


@dp.message(AddButtonStates.waiting_url)
async def state_add_btn_url(message: Message, state: FSMContext):
    url = message.text.strip()
    if not url.startswith("http://") and not url.startswith("https://") and not url.startswith("tg://"):
        url = f"https://{url}"
    await state.update_data(url=url)
    await state.set_state(AddButtonStates.waiting_style)

    text = (
        "➕ <b>STEP 3/4: CHOOSE BUTTON COLOR</b>\n\n"
        "Select the color/style for this button:"
    )
    await message.answer(text=text, reply_markup=build_color_select_kb("new_btn"), parse_mode="HTML")


@dp.callback_query(F.data.startswith("set_color:new_btn:"))
async def callback_add_btn_color(callback: CallbackQuery, state: FSMContext):
    color = callback.data.split(":")[3]
    style_val = None if color == "default" else color
    await state.update_data(style=style_val)
    await state.set_state(AddButtonStates.waiting_emoji)

    text = (
        "➕ <b>STEP 4/4: PREMIUM CUSTOM EMOJI ID</b>\n\n"
        "Send the <b>Custom Emoji ID</b> (e.g. <code>5258096772776991776</code>).\n"
        "Or send <code>skip</code> to use no custom emoji icon."
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(AddButtonStates.waiting_emoji)
async def state_add_btn_emoji(message: Message, state: FSMContext):
    val = message.text.strip()
    emoji_id = None if val.lower() in ["skip", "none", "0", "no"] else val
    data = await state.get_data()
    btn_data = {
        "text": data.get("text", "New Button"),
        "url": data.get("url", "https://t.me/telegram"),
        "style": data.get("style", "danger"),
        "icon_custom_emoji_id": emoji_id,
        "enabled": True,
    }
    new_id = config_manager.add_channel(btn_data)
    await state.clear()
    await message.answer(
        f"🎉 <b>Success! Button #{new_id} added!</b>\n\n"
        f"• Text: <code>{btn_data['text']}</code>\n"
        f"• Link: <code>{btn_data['url']}</code>\n"
        f"• Style: {get_style_badge(btn_data['style'])}\n"
        f"• Emoji ID: <code>{emoji_id or 'None'}</code>",
        parse_mode="HTML",
    )
    channels = config_manager.get_channels()
    row_count = config_manager.get("channels_per_row", 2)
    await message.answer("🔘 <b>Updated Buttons List:</b>", reply_markup=build_buttons_list_kb(channels, row_count), parse_mode="HTML")


# ==============================================================================
# "GENERATE KEY" BUTTON SETTINGS
# ==============================================================================
async def render_gk_settings(callback: CallbackQuery):
    gk = config_manager.get("generate_key_button", {})
    style_badge = get_style_badge(gk.get("style"))
    status = "Active ✅" if gk.get("enabled", True) else "Disabled ❌"
    emoji_id = gk.get("icon_custom_emoji_id") or "None"
    action_type = gk.get("action_type", "url")

    text = (
        "🔑 <b>'GENERATE KEY' BUTTON SETTINGS</b>\n\n"
        f"• <b>Text:</b> <code>{gk.get('text')}</code>\n"
        f"• <b>Action Type:</b> <code>{'URL Link' if action_type == 'url' else 'Pop-up Alert'}</code>\n"
        f"• <b>Link URL:</b> <code>{gk.get('url')}</code>\n"
        f"• <b>Pop-up Message:</b> <code>{gk.get('callback_msg')}</code>\n"
        f"• <b>Button Color:</b> {style_badge}\n"
        f"• <b>Custom Emoji ID:</b> <code>{emoji_id}</code>\n"
        f"• <b>Status:</b> {status}\n\n"
        "Customize options using the buttons below:"
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_gen_key_kb(gk), parse_mode="HTML")


@dp.callback_query(F.data == "admin:gen_key")
async def callback_admin_gen_key(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return
    await render_gk_settings(callback)
    await callback.answer()


@dp.callback_query(F.data == "gk:toggle")
async def callback_gk_toggle(callback: CallbackQuery):
    gk = config_manager.get("generate_key_button", {})
    gk["enabled"] = not gk.get("enabled", True)
    config_manager.set("generate_key_button", gk)
    await render_gk_settings(callback)
    await callback.answer("Button visibility toggled!")


@dp.callback_query(F.data == "gk:toggle_type")
async def callback_gk_toggle_type(callback: CallbackQuery):
    gk = config_manager.get("generate_key_button", {})
    current_type = gk.get("action_type", "url")
    gk["action_type"] = "callback" if current_type == "url" else "url"
    config_manager.set("generate_key_button", gk)
    await render_gk_settings(callback)
    await callback.answer("Action type updated!")


@dp.callback_query(F.data == "gk:style")
async def callback_gk_style(callback: CallbackQuery):
    text = (
        "🎨 <b>SELECT 'GENERATE KEY' BUTTON COLOR</b>\n\n"
        "Choose color style for the Key button:"
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_color_select_kb("gk"), parse_mode="HTML")
    await callback.answer()


@dp.callback_query(F.data == "gk:text")
async def callback_gk_edit_text(callback: CallbackQuery, state: FSMContext):
    await state.set_state(GenKeyStates.waiting_text)
    text = "✏️ <b>Enter new text for the Key Button:</b>\n(e.g., <code>🟢 GENERATE KEY</code> or <code>🔥 GET FREE KEY NOW</code>)"
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(GenKeyStates.waiting_text)
async def state_save_gk_text(message: Message, state: FSMContext):
    new_text = message.text.strip()
    gk = config_manager.get("generate_key_button", {})
    gk["text"] = new_text
    config_manager.set("generate_key_button", gk)
    await state.clear()
    await message.answer(f"✅ Key button text updated to: <b>{new_text}</b>", parse_mode="HTML")
    await message.answer("🔑 <b>Generate Key Settings:</b>", reply_markup=build_gen_key_kb(gk), parse_mode="HTML")


@dp.callback_query(F.data == "gk:url")
async def callback_gk_edit_url(callback: CallbackQuery, state: FSMContext):
    await state.set_state(GenKeyStates.waiting_url)
    text = "🔗 <b>Send the URL for the Key Button:</b>\n(e.g. <code>https://t.me/example</code> or key website)"
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(GenKeyStates.waiting_url)
async def state_save_gk_url(message: Message, state: FSMContext):
    new_url = message.text.strip()
    if not new_url.startswith("http://") and not new_url.startswith("https://") and not new_url.startswith("tg://"):
        new_url = f"https://{new_url}"
    gk = config_manager.get("generate_key_button", {})
    gk["url"] = new_url
    config_manager.set("generate_key_button", gk)
    await state.clear()
    await message.answer(f"✅ Key button URL updated to: <code>{new_url}</code>", parse_mode="HTML")
    await message.answer("🔑 <b>Generate Key Settings:</b>", reply_markup=build_gen_key_kb(gk), parse_mode="HTML")


@dp.callback_query(F.data == "gk:msg")
async def callback_gk_edit_msg(callback: CallbackQuery, state: FSMContext):
    await state.set_state(GenKeyStates.waiting_msg)
    text = "💬 <b>Send the Pop-up Message shown when user clicks Generate Key:</b>"
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(GenKeyStates.waiting_msg)
async def state_save_gk_msg(message: Message, state: FSMContext):
    msg = message.text.strip()
    gk = config_manager.get("generate_key_button", {})
    gk["callback_msg"] = msg
    config_manager.set("generate_key_button", gk)
    await state.clear()
    await message.answer("✅ Pop-up message updated successfully!")
    await message.answer("🔑 <b>Generate Key Settings:</b>", reply_markup=build_gen_key_kb(gk), parse_mode="HTML")


@dp.callback_query(F.data == "gk:emoji")
async def callback_gk_edit_emoji(callback: CallbackQuery, state: FSMContext):
    await state.set_state(GenKeyStates.waiting_emoji)
    text = "⭐ <b>Send Custom Emoji ID for Generate Key Button:</b>\n(Or send <code>none</code> to remove)"
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(GenKeyStates.waiting_emoji)
async def state_save_gk_emoji(message: Message, state: FSMContext):
    val = message.text.strip()
    emoji_id = None if val.lower() in ["none", "remove", "0", "no"] else val
    gk = config_manager.get("generate_key_button", {})
    gk["icon_custom_emoji_id"] = emoji_id
    config_manager.set("generate_key_button", gk)
    await state.clear()
    await message.answer(f"✅ Key button emoji ID set to: <code>{emoji_id}</code>", parse_mode="HTML")
    await message.answer("🔑 <b>Generate Key Settings:</b>", reply_markup=build_gen_key_kb(gk), parse_mode="HTML")


# ==============================================================================
# BANNER PHOTO & WELCOME TEXT SETTINGS
# ==============================================================================
@dp.callback_query(F.data == "admin:welcome")
async def callback_admin_welcome(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return

    text = (
        "🖼️ <b>WELCOME MESSAGE & BANNER PHOTO SETTINGS</b>\n\n"
        "• <b>Current Welcome Caption:</b>\n"
        f"<blockquote>{config_manager.get('welcome_text')}</blockquote>\n\n"
        "• <b>Banner Photo Status:</b> "
        f"{'Custom Uploaded Photo ✅' if config_manager.get('banner_file_id') else 'Default URL Image 🌐'}\n\n"
        "Choose an option to update:"
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_welcome_settings_kb(), parse_mode="HTML")
    await callback.answer()


@dp.callback_query(F.data == "welc:text")
async def callback_welc_edit_text(callback: CallbackQuery, state: FSMContext):
    await state.set_state(WelcomeStates.waiting_text)
    text = "📝 <b>Send the new Welcome Caption:</b>\n(Supports emoji, bold, stylish fonts, lines)"
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(WelcomeStates.waiting_text)
async def state_save_welcome_text(message: Message, state: FSMContext):
    if message.entities or message.caption_entities:
        new_text = message.html_text
    else:
        new_text = message.text or message.caption or ""
    config_manager.set("welcome_text", new_text)
    await state.clear()
    await message.answer("✅ Welcome text updated successfully!", parse_mode="HTML")
    await message.answer("🖼️ <b>Welcome Settings:</b>", reply_markup=build_welcome_settings_kb(), parse_mode="HTML")


@dp.callback_query(F.data == "welc:photo")
async def callback_welc_edit_photo(callback: CallbackQuery, state: FSMContext):
    await state.set_state(WelcomeStates.waiting_photo)
    text = (
        "🖼️ <b>SEND NEW BANNER PHOTO</b>\n\n"
        "• Either <b>upload a photo directly</b> to this chat.\n"
        "• Or <b>send an image URL</b> (ending with .png / .jpg).\n\n"
        "This photo will appear at the top when users type /start."
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(WelcomeStates.waiting_photo)
async def state_save_welcome_photo(message: Message, state: FSMContext):
    if message.photo:
        file_id = message.photo[-1].file_id
        config_manager.set("banner_file_id", file_id)
        await state.clear()
        await message.answer("✅ Banner photo updated from uploaded image!", reply_markup=build_welcome_settings_kb())
    elif message.text and (message.text.startswith("http://") or message.text.startswith("https://")):
        config_manager.set("banner_photo", message.text.strip())
        config_manager.set("banner_file_id", None)
        await state.clear()
        await message.answer("✅ Banner photo URL updated successfully!", reply_markup=build_welcome_settings_kb())
    else:
        await message.answer("❌ Please send a photo or a valid image URL (or click Cancel).", reply_markup=build_cancel_kb())


# ==============================================================================
# VOICE NOTE SETTINGS
# ==============================================================================
@dp.callback_query(F.data == "admin:voice")
async def callback_admin_voice(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return

    cfg = config_manager.config
    status = "ENABLED 🔊" if cfg.get("voice_enabled") else "DISABLED 🔇"
    caption = cfg.get("voice_caption", "None")
    has_file = "Voice Audio Uploaded ✅" if cfg.get("voice_file_id") else "No Audio Uploaded Yet ⚠️"

    text = (
        "🎙️ <b>VOICE NOTE SETTINGS</b>\n\n"
        f"• <b>Status:</b> {status}\n"
        f"• <b>Audio File:</b> {has_file}\n"
        f"• <b>Caption:</b> <code>{caption}</code>\n\n"
        "When enabled, the bot sends this voice note right after /start.\n"
        "<i>(Matching Image 1 & 2: 'KEY CHIYE ? VOICE SUNO')</i>"
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_voice_settings_kb(cfg), parse_mode="HTML")
    await callback.answer()


@dp.callback_query(F.data == "voice:toggle")
async def callback_voice_toggle(callback: CallbackQuery):
    cur = config_manager.get("voice_enabled", False)
    config_manager.set("voice_enabled", not cur)
    await callback_admin_voice(callback)


@dp.callback_query(F.data == "voice:caption")
async def callback_voice_caption(callback: CallbackQuery, state: FSMContext):
    await state.set_state(VoiceStates.waiting_caption)
    text = "✏️ <b>Send new Voice Caption:</b>\n(e.g., <code>➡️ KEY CHIYE ? VOICE SUNO</code>)"
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(VoiceStates.waiting_caption)
async def state_save_voice_caption(message: Message, state: FSMContext):
    caption = message.text.strip()
    config_manager.set("voice_caption", caption)
    await state.clear()
    await message.answer(f"✅ Voice caption updated to: <b>{caption}</b>", parse_mode="HTML")
    await message.answer("🎙️ <b>Voice Settings:</b>", reply_markup=build_voice_settings_kb(config_manager.config), parse_mode="HTML")


@dp.callback_query(F.data == "voice:upload")
async def callback_voice_upload(callback: CallbackQuery, state: FSMContext):
    await state.set_state(VoiceStates.waiting_file)
    text = (
        "🎙️ <b>UPLOAD VOICE NOTE / AUDIO</b>\n\n"
        "Please record and send a <b>Voice Message</b> or upload an <b>Audio file (.mp3 / .ogg)</b>."
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(VoiceStates.waiting_file)
async def state_save_voice_file(message: Message, state: FSMContext):
    file_id = None
    if message.voice:
        file_id = message.voice.file_id
    elif message.audio:
        file_id = message.audio.file_id

    if file_id:
        config_manager.set("voice_file_id", file_id)
        config_manager.set("voice_enabled", True)
        await state.clear()
        await message.answer("🎉 Voice note uploaded and enabled successfully!", reply_markup=build_voice_settings_kb(config_manager.config))
    else:
        await message.answer("❌ Please send an audio or voice note message (or click Cancel).", reply_markup=build_cancel_kb())


# ==============================================================================
# ADMIN MANAGEMENT
# ==============================================================================
@dp.callback_query(F.data == "admin:admins")
async def callback_admin_admins(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return

    admins = config_manager.get("admins", [])
    text = (
        "👥 <b>ADMIN MANAGEMENT PANEL</b>\n\n"
        f"👑 <b>Bot Owner ID:</b> <code>{OWNER_ID or 'Not Set'}</code>\n\n"
        "🛡️ <b>Current Authorized Admins:</b>\n"
    )
    if admins:
        for idx, adm in enumerate(admins, 1):
            text += f"{idx}. <code>{adm}</code>\n"
    else:
        text += "<i>No additional admins added yet.</i>\n"

    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_admins_list_kb(), parse_mode="HTML")
    await callback.answer()


@dp.callback_query(F.data == "admin_mgr:add")
async def callback_admin_add(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminMgrStates.waiting_add_id)
    text = "➕ <b>Send the Telegram User ID of the new Admin to add:</b>\n(Must be a numeric ID like <code>7607314151</code>)"
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(AdminMgrStates.waiting_add_id)
async def state_save_admin_add(message: Message, state: FSMContext):
    val = message.text.strip()
    if not val.isdigit():
        await message.answer("❌ Invalid ID. Must be numeric.", reply_markup=build_cancel_kb())
        return

    target_id = int(val)
    if config_manager.add_admin(target_id):
        await state.clear()
        await message.answer(f"🎉 User ID <code>{target_id}</code> added as Admin!", parse_mode="HTML")
        await callback_admin_admins_message(message)
    else:
        await message.answer("User is already an admin!", reply_markup=build_cancel_kb())


@dp.callback_query(F.data == "admin_mgr:remove")
async def callback_admin_remove(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminMgrStates.waiting_remove_id)
    text = "➖ <b>Send the Telegram User ID of the Admin to remove:</b>"
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(AdminMgrStates.waiting_remove_id)
async def state_save_admin_remove(message: Message, state: FSMContext):
    val = message.text.strip()
    if not val.isdigit():
        await message.answer("❌ Invalid ID. Must be numeric.", reply_markup=build_cancel_kb())
        return

    target_id = int(val)
    if config_manager.remove_admin(target_id):
        await state.clear()
        await message.answer(f"✅ Admin <code>{target_id}</code> removed!", parse_mode="HTML")
        await callback_admin_admins_message(message)
    else:
        await message.answer("ID not found in admin list!", reply_markup=build_cancel_kb())


async def callback_admin_admins_message(message: Message):
    admins = config_manager.get("admins", [])
    text = (
        "👥 <b>ADMIN MANAGEMENT PANEL</b>\n\n"
        f"👑 <b>Bot Owner ID:</b> <code>{OWNER_ID or 'Not Set'}</code>\n\n"
        "🛡️ <b>Current Authorized Admins:</b>\n"
    )
    for idx, adm in enumerate(admins, 1):
        text += f"{idx}. <code>{adm}</code>\n"
    await message.answer(text=text, reply_markup=build_admins_list_kb(), parse_mode="HTML")


# ==============================================================================
# BROADCAST FEATURE
# ==============================================================================
@dp.callback_query(F.data == "admin:broadcast")
async def callback_admin_broadcast(callback: CallbackQuery, state: FSMContext):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Unauthorized!", show_alert=True)
        return

    user_count = await get_user_count()
    await state.set_state(BroadcastStates.waiting_content)
    text = (
        f"📢 <b>BROADCAST ANNOUNCEMENT</b>\n\n"
        f"Target Audience: <b>{user_count} bot users</b>\n\n"
        "Send any message you want to broadcast (Text, Photo with caption, Video, etc.).\n"
        "It will be forwarded to all active users immediately."
    )
    if callback.message:
        await callback.message.edit_text(text=text, reply_markup=build_cancel_kb(), parse_mode="HTML")
    await callback.answer()


@dp.message(BroadcastStates.waiting_content)
async def state_execute_broadcast(message: Message, state: FSMContext):
    user_ids = await get_all_user_ids()
    status_msg = await message.answer(f"🚀 Broadcasting message to {len(user_ids)} users...")
    await state.clear()

    success = 0
    failed = 0

    for uid in user_ids:
        try:
            await message.copy_to(chat_id=uid)
            success += 1
            await asyncio.sleep(0.05)  # Telegram rate-limit prevention
        except Exception:
            failed += 1

    await status_msg.edit_text(
        f"📢 <b>Broadcast Completed!</b>\n\n"
        f"• Sent Successfully: <code>{success}</code>\n"
        f"• Failed/Blocked: <code>{failed}</code>",
        parse_mode="HTML",
    )
    await message.answer("⚡ <b>Admin Menu:</b>", reply_markup=build_admin_main_kb(), parse_mode="HTML")


# ==============================================================================
# CANCEL ACTION HANDLER
# ==============================================================================
@dp.callback_query(F.data == "fsm_cancel")
async def handle_fsm_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.answer("❌ Action cancelled.")
    await callback_admin_main(callback, state)


# ==============================================================================
# BOT STARTUP & MAIN
# ==============================================================================
async def on_startup(bot: Bot):
    await init_db()
    # Configure Bot Commands Menu exactly matching Image 3!
    commands = [
        BotCommand(command="start", description="paid hack free 🆓"),
        BotCommand(command="admin", description="only admin and owner"),
    ]
    try:
        await bot.set_my_commands(commands)
        logger.info("Bot commands menu set successfully.")
    except Exception as e:
        logger.warning(f"Failed to set bot commands: {e}")

    try:
        bot_info = await bot.get_me()
        print("=" * 60)
        print(f"🤖 Bot Started Successfully: @{bot_info.username} [ID: {bot_info.id}]")
        print(f"👑 Owner ID: {OWNER_ID or 'Not Set (Set OWNER_ID in .env)'}")
        print(f"🎨 Buttons Color & Custom Emoji System: ACTIVE")
        print("=" * 60)
    except Exception as e:
        logger.warning(f"Could not fetch bot info: {e}")


async def main():
    token = TOKEN
    if not token or ":" not in token:
        print("\n" + "!" * 60)
        print("[SETUP REQUIRED] Telegram Bot Token is missing or invalid!")
        print("Please edit the .env file in this directory and set:")
        print("TELEGRAM_BOT_TOKEN=your_token_from_botfather")
        print("OWNER_ID=your_numeric_user_id")
        print("!" * 60 + "\n")
        return

    from aiohttp.resolver import ThreadedResolver
    from aiogram.client.session.aiohttp import AiohttpSession

    session = AiohttpSession()
    session._connector_init = {"resolver": ThreadedResolver()}
    bot_instance = Bot(token=token, session=session)
    dp.startup.register(on_startup)
    print("Starting bot polling... Press Ctrl+C to stop.")
    await dp.start_polling(bot_instance)


if __name__ == "__main__":
    asyncio.run(main())
