from typing import List, Dict, Any, Optional
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

def make_button(btn_data: Dict[str, Any]) -> InlineKeyboardButton:
    """Creates an InlineKeyboardButton with style and custom emoji icon."""
    text = btn_data.get("text", "Button")
    style = btn_data.get("style")
    icon_id = btn_data.get("icon_custom_emoji_id")
    url = btn_data.get("url")
    action_type = btn_data.get("action_type", "url")
    
    kwargs: Dict[str, Any] = {"text": text}
    
    # Telegram Bot API 8.0 colored button styles: 'primary', 'success', 'danger'
    if style in ["primary", "success", "danger"]:
        kwargs["style"] = style
        
    # Telegram Premium custom emoji ID inside button
    if icon_id and str(icon_id).strip():
        kwargs["icon_custom_emoji_id"] = str(icon_id).strip()
        
    if action_type == "callback" or not url:
        btn_id = btn_data.get("id", "0")
        kwargs["callback_data"] = f"btn_click:{btn_id}"
    else:
        kwargs["url"] = url
        
    return InlineKeyboardButton(**kwargs)

def build_user_keyboard(config: Dict[str, Any]) -> InlineKeyboardMarkup:
    """Builds the public /start inline keyboard matching the screenshots."""
    rows: List[List[InlineKeyboardButton]] = []
    
    channels = config.get("channels", [])
    channels_per_row = config.get("channels_per_row", 2)
    
    current_row: List[InlineKeyboardButton] = []
    for ch in channels:
        if not ch.get("enabled", True):
            continue
        current_row.append(make_button(ch))
        if len(current_row) >= channels_per_row:
            rows.append(current_row)
            current_row = []
            
    if current_row:
        rows.append(current_row)
        
    # Generate Key button
    key_btn = config.get("generate_key_button", {})
    if key_btn.get("enabled", True):
        kwargs: Dict[str, Any] = {"text": key_btn.get("text", "🟢 GENERATE KEY")}
        style = key_btn.get("style", "success")
        if style in ["primary", "success", "danger"]:
            kwargs["style"] = style
            
        icon_id = key_btn.get("icon_custom_emoji_id")
        if icon_id and str(icon_id).strip():
            kwargs["icon_custom_emoji_id"] = str(icon_id).strip()
            
        if key_btn.get("action_type") == "callback" or not key_btn.get("url"):
            kwargs["callback_data"] = "user_gen_key_click"
        else:
            kwargs["url"] = key_btn["url"]
            
        rows.append([InlineKeyboardButton(**kwargs)])
        
    return InlineKeyboardMarkup(inline_keyboard=rows)

def build_admin_main_kb() -> InlineKeyboardMarkup:
    """Main dashboard keyboard for /admin panel."""
    kb = [
        [
            InlineKeyboardButton(text="🔘 Manage Channels", callback_data="admin:buttons", style="primary"),
            InlineKeyboardButton(text="🔑 Key Button Settings", callback_data="admin:gen_key", style="success")
        ],
        [
            InlineKeyboardButton(text="🖼️ Banner & Welcome Text", callback_data="admin:welcome"),
            InlineKeyboardButton(text="🎙️ Voice Note Settings", callback_data="admin:voice")
        ],
        [
            InlineKeyboardButton(text="📢 Broadcast Message", callback_data="admin:broadcast", style="primary"),
            InlineKeyboardButton(text="👥 Manage Admins", callback_data="admin:admins")
        ],
        [
            InlineKeyboardButton(text="📊 Bot Statistics", callback_data="admin:stats"),
            InlineKeyboardButton(text="👁️ Live Preview /start", callback_data="admin:preview")
        ],
        [
            InlineKeyboardButton(text="🔄 Refresh Panel", callback_data="admin:refresh"),
            InlineKeyboardButton(text="❌ Close Panel", callback_data="admin:close", style="danger")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def get_style_badge(style: Optional[str]) -> str:
    if style == "primary":
        return "🔵 Blue"
    elif style == "success":
        return "🟢 Green"
    elif style == "danger":
        return "🔴 Red"
    return "⚪ Default"

def build_buttons_list_kb(channels: List[Dict[str, Any]], channels_per_row: int) -> InlineKeyboardMarkup:
    """Keyboard listing all current buttons to edit or add."""
    rows: List[List[InlineKeyboardButton]] = []
    
    for ch in channels:
        cid = ch["id"]
        status = "✅" if ch.get("enabled", True) else "❌"
        style_icon = "🔴" if ch.get("style") == "danger" else ("🟢" if ch.get("style") == "success" else ("🔵" if ch.get("style") == "primary" else "⚪"))
        title = f"{status} {style_icon} {ch.get('text', f'Button #{cid}')}"
        rows.append([
            InlineKeyboardButton(text=title, callback_data=f"btn_edit:{cid}")
        ])
        
    rows.append([
        InlineKeyboardButton(text="➕ Add New Button", callback_data="btn_add", style="success"),
        InlineKeyboardButton(text=f"↔️ Layout: {channels_per_row}/Row", callback_data="btn_toggle_layout", style="primary")
    ])
    rows.append([
        InlineKeyboardButton(text="🔙 Back to Admin Menu", callback_data="admin:main")
    ])
    return InlineKeyboardMarkup(inline_keyboard=rows)

def build_button_detail_kb(ch: Dict[str, Any]) -> InlineKeyboardMarkup:
    """Settings keyboard for a specific channel button."""
    cid = ch["id"]
    is_enabled = ch.get("enabled", True)
    toggle_text = "Disable Button ❌" if is_enabled else "Enable Button ✅"
    style_badge = get_style_badge(ch.get("style"))
    
    kb = [
        [
            InlineKeyboardButton(text="✏️ Edit Name", callback_data=f"btn_prop:text:{cid}"),
            InlineKeyboardButton(text="🔗 Edit Link", callback_data=f"btn_prop:url:{cid}")
        ],
        [
            InlineKeyboardButton(text=f"🎨 Color: {style_badge}", callback_data=f"btn_prop:style:{cid}", style="primary"),
            InlineKeyboardButton(text="⭐ Edit Custom Emoji ID", callback_data=f"btn_prop:emoji:{cid}")
        ],
        [
            InlineKeyboardButton(text=toggle_text, callback_data=f"btn_prop:toggle:{cid}"),
            InlineKeyboardButton(text="🗑️ Delete Button", callback_data=f"btn_delete:{cid}", style="danger")
        ],
        [
            InlineKeyboardButton(text="🔙 Back to Buttons List", callback_data="admin:buttons")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def build_color_select_kb(target_type: str, target_id: Any = "0") -> InlineKeyboardMarkup:
    """Color selection keyboard."""
    kb = [
        [
            InlineKeyboardButton(text="🔴 Danger (Red)", callback_data=f"set_color:{target_type}:{target_id}:danger", style="danger"),
            InlineKeyboardButton(text="🟢 Success (Green)", callback_data=f"set_color:{target_type}:{target_id}:success", style="success")
        ],
        [
            InlineKeyboardButton(text="🔵 Primary (Blue)", callback_data=f"set_color:{target_type}:{target_id}:primary", style="primary"),
            InlineKeyboardButton(text="⚪ Default (Normal)", callback_data=f"set_color:{target_type}:{target_id}:default")
        ],
        [
            InlineKeyboardButton(text="🔙 Cancel", callback_data="fsm_cancel")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def build_gen_key_kb(key_btn: Dict[str, Any]) -> InlineKeyboardMarkup:
    """Keyboard for configuring Generate Key button."""
    is_enabled = key_btn.get("enabled", True)
    toggle_text = "Disable Button ❌" if is_enabled else "Enable Button ✅"
    style_badge = get_style_badge(key_btn.get("style"))
    action_type = key_btn.get("action_type", "url")
    action_label = "🌐 Link (URL)" if action_type == "url" else "💬 Popup Message"
    
    kb = [
        [
            InlineKeyboardButton(text="✏️ Change Text", callback_data="gk:text"),
            InlineKeyboardButton(text=f"⚙️ Type: {action_label}", callback_data="gk:toggle_type")
        ],
        [
            InlineKeyboardButton(text="🔗 Edit URL / Link", callback_data="gk:url"),
            InlineKeyboardButton(text="💬 Edit Popup Text", callback_data="gk:msg")
        ],
        [
            InlineKeyboardButton(text=f"🎨 Color: {style_badge}", callback_data="gk:style", style="primary"),
            InlineKeyboardButton(text="⭐ Custom Emoji ID", callback_data="gk:emoji")
        ],
        [
            InlineKeyboardButton(text=toggle_text, callback_data="gk:toggle"),
            InlineKeyboardButton(text="🔙 Back to Menu", callback_data="admin:main")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def build_welcome_settings_kb() -> InlineKeyboardMarkup:
    """Keyboard for Welcome Message & Banner Photo."""
    kb = [
        [
            InlineKeyboardButton(text="📝 Edit Welcome Text", callback_data="welc:text", style="primary"),
            InlineKeyboardButton(text="🖼️ Change Banner Photo", callback_data="welc:photo", style="primary")
        ],
        [
            InlineKeyboardButton(text="🔙 Back to Admin Menu", callback_data="admin:main")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def build_voice_settings_kb(config: Dict[str, Any]) -> InlineKeyboardMarkup:
    """Keyboard for Voice Note settings."""
    voice_enabled = config.get("voice_enabled", False)
    toggle_text = "Voice: ENABLED 🔊" if voice_enabled else "Voice: DISABLED 🔇"
    
    kb = [
        [
            InlineKeyboardButton(text="🎙️ Upload New Voice Note", callback_data="voice:upload", style="primary"),
            InlineKeyboardButton(text="✏️ Edit Voice Caption", callback_data="voice:caption")
        ],
        [
            InlineKeyboardButton(text=toggle_text, callback_data="voice:toggle", style="success" if voice_enabled else "danger")
        ],
        [
            InlineKeyboardButton(text="🔙 Back to Admin Menu", callback_data="admin:main")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def build_admins_list_kb() -> InlineKeyboardMarkup:
    """Keyboard for managing admins."""
    kb = [
        [
            InlineKeyboardButton(text="➕ Add New Admin", callback_data="admin_mgr:add", style="success"),
            InlineKeyboardButton(text="➖ Remove Admin", callback_data="admin_mgr:remove", style="danger")
        ],
        [
            InlineKeyboardButton(text="🔙 Back to Admin Menu", callback_data="admin:main")
        ]
    ]
    return InlineKeyboardMarkup(inline_keyboard=kb)

def build_cancel_kb() -> InlineKeyboardMarkup:
    """Cancel keyboard for states."""
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Cancel", callback_data="fsm_cancel", style="danger")]
    ])
