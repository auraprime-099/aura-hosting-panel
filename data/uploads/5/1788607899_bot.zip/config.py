import json
import os
from typing import Dict, Any, List, Optional
from dotenv import load_dotenv

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
CONFIG_FILE = os.path.join(DATA_DIR, 'bot_config.json')

os.makedirs(DATA_DIR, exist_ok=True)

DEFAULT_CONFIG: Dict[str, Any] = {
    'welcome_text': (
        '🔥 𝐖𝐄𝐋𝐂𝐎𝐌𝐄 ⚡* 𝐀𝐮𝐑𝐀 𝐎𝐖𝐍𝐄𝐑 -//- 🕊️\n\n'
        '🚫 𝐉𝐎𝐈𝐍 𝐀𝐋𝐋 𝐂𝐇𝐀𝐍𝐍𝐄𝐋𝐒 𝐓𝐎 𝐔𝐍𝐋𝐎𝐂𝐊 📢\n\n'
        '🟢 𝐇𝐎𝐖 𝐓𝐎 𝐆𝐄𝐓 𝐊𝐄𝐘 🔗 💨\n'
        '📈 𝐆𝐄𝐓 𝐊𝐄𝐘 🫣'
    ),
    'banner_photo': 'https://raw.githubusercontent.com/aiogram/aiogram/dev-3.x/docs/_static/aiogram.png',
    'banner_file_id': None,
    'voice_enabled': False,
    'voice_file_id': None,
    'voice_caption': '➡️ KEY CHIYE ? VOICE SUNO',
    'generate_key_button': {
        'text': '🟢 GENERATE KEY',
        'url': 'https://t.me/example',
        'action_type': 'url',
        'callback_msg': '🔑 Your Key: FREE-KEY-2026-XYZ\nValid for 24 Hours! Enjoy!',
        'style': 'success',
        'icon_custom_emoji_id': '5258503720928288433',
        'enabled': True
    },
    'channels_per_row': 2,
    'channels': [
        {
            'id': 1,
            'text': '🗝 CHANEL 1',
            'url': 'https://t.me/telegram',
            'style': 'danger',
            'icon_custom_emoji_id': '5258096772776991776',
            'enabled': True
        },
        {
            'id': 2,
            'text': '🗝 CHANEL 2',
            'url': 'https://t.me/telegram',
            'style': 'danger',
            'icon_custom_emoji_id': '5258096772776991776',
            'enabled': True
        },
        {
            'id': 3,
            'text': '🗝 CHANEL 3',
            'url': 'https://t.me/telegram',
            'style': 'danger',
            'icon_custom_emoji_id': '5258096772776991776',
            'enabled': True
        },
        {
            'id': 4,
            'text': '🗝 CHANEL 4',
            'url': 'https://t.me/telegram',
            'style': 'danger',
            'icon_custom_emoji_id': '5258096772776991776',
            'enabled': True
        },
        {
            'id': 5,
            'text': '🗝 CHANEL 5',
            'url': 'https://t.me/telegram',
            'style': 'danger',
            'icon_custom_emoji_id': '5258096772776991776',
            'enabled': True
        },
        {
            'id': 6,
            'text': '🗝 CHANEL 6',
            'url': 'https://t.me/telegram',
            'style': 'danger',
            'icon_custom_emoji_id': '5258096772776991776',
            'enabled': True
        },
        {
            'id': 7,
            'text': '🗝 CHANEL 7',
            'url': 'https://t.me/telegram',
            'style': 'danger',
            'icon_custom_emoji_id': '5258096772776991776',
            'enabled': True
        }
    ],
    'force_join_enabled': False,
    'admins': []
}

class ConfigManager:
    def __init__(self, filepath: str = CONFIG_FILE):
        self.filepath = filepath
        self.config: Dict[str, Any] = {}
        self.load()

    def load(self) -> None:
        if not os.path.exists(self.filepath):
            self.config = DEFAULT_CONFIG.copy()
            self.save()
            return
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.config = DEFAULT_CONFIG.copy()
                self.config.update(data)
        except Exception as e:
            print(f'[ERROR] Loading config failed: {e}. Using defaults.')
            self.config = DEFAULT_CONFIG.copy()

    def save(self) -> None:
        try:
            with open(self.filepath, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=4, ensure_ascii=False)
        except Exception as e:
            print(f'[ERROR] Saving config failed: {e}')

    def get(self, key: str, default: Any = None) -> Any:
        return self.config.get(key, default)

    def set(self, key: str, value: Any) -> None:
        self.config[key] = value
        self.save()

    def is_admin(self, user_id: int, owner_id: Optional[int] = None) -> bool:
        if owner_id and user_id == owner_id:
            return True
        admins = self.config.get('admins', [])
        return user_id in admins

    def add_admin(self, user_id: int) -> bool:
        admins = self.config.setdefault('admins', [])
        if user_id not in admins:
            admins.append(user_id)
            self.save()
            return True
        return False

    def remove_admin(self, user_id: int) -> bool:
        admins = self.config.setdefault('admins', [])
        if user_id in admins:
            admins.remove(user_id)
            self.save()
            return True
        return False

    def get_channels(self) -> List[Dict[str, Any]]:
        return self.config.get('channels', [])

    def add_channel(self, channel_data: Dict[str, Any]) -> int:
        channels = self.config.setdefault('channels', [])
        new_id = max([c.get('id', 0) for c in channels], default=0) + 1
        channel_data['id'] = new_id
        if 'enabled' not in channel_data:
            channel_data['enabled'] = True
        channels.append(channel_data)
        self.save()
        return new_id

    def update_channel(self, channel_id: int, updates: Dict[str, Any]) -> bool:
        channels = self.config.setdefault('channels', [])
        for ch in channels:
            if ch.get('id') == channel_id:
                ch.update(updates)
                self.save()
                return True
        return False

    def delete_channel(self, channel_id: int) -> bool:
        channels = self.config.setdefault('channels', [])
        initial_len = len(channels)
        self.config['channels'] = [c for c in channels if c.get('id') != channel_id]
        if len(self.config['channels']) < initial_len:
            self.save()
            return True
        return False

config_manager = ConfigManager()
