Yeh **clean, professional aur deploy-ready README.md** version hai — bot selling / GitHub public repo / private showcase sab ke liye fit. Emojis balanced rakhe hain ⚡
(“start command: `bash start.sh`” properly add kiya hai)

---

# ⚡ God-Level TempMail Bot V3

**Ultra-Fast Temporary Email Generator & OTP Receiver**

> 🔥 Developed by **Ars**

---

## 🚀 Key Features

* ⚡ **Ultra-Fast Temp-Mail Creation**
* 📨 **Instant Inbox & OTP Reader**
* 📬 **Multi-Mailbox Support**
* 🛡 **MongoDB Storage** (Persistent & Secure)
* ⚙ **Advanced Admin Panel**
* 📢 **Broadcast Messages to All Users**
* 🗑 **Clear / Reset Mailboxes**
* 🎯 **Ultra-Short Callback System (2B Optimized)**
* ✔ **Fully Optimized for Deployment**
  *(Railway • Vercel • Render)*

---

## 🧠 Use Cases

* Account verification testing
* OTP receiving & monitoring
* Temporary email automation
* Bot-based email workflows

---

## 📦 Tech Stack

* **Python 3**
* **Pyrogram**
* **MongoDB**
* **Mail.tm API**
* **BeautifulSoup4**
* **Requests**

---

## ⚙ Installation & Setup

### 🔹 Clone Repository

```bash
git clone https://github.com/yourusername/tempmail-bot-v3.git
cd tempmail-bot-v3
```

### 🔹 Install Dependencies

```bash
pip install -r requirements.txt
```

### 🔹 Environment Variables

Create `.env` file:

```env
API_HASH=""
API_ID=
BOT_TOKEN=
DB_NAME="default"
MONGO_URI=
OWNER_ID="
```

---

## ▶ Start Bot

```bash
bash start.sh
```

---

## 🚀 Deployment Ready

* ✔ Railway
* ✔ Render
* ✔ Vercel
* ✔ VPS / Local Server

No extra configuration needed 🔥

---

## 🛡 Security & Performance

* Optimized async handling
* Secure database storage
* Clean API calls
* Low latency inbox fetch
