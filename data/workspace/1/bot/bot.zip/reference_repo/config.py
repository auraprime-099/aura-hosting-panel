from dotenv import load_dotenv
import os

load_dotenv()

API_ID=8676658195
API_HASH="a55f31ace28b9b29a922645c43d92252"
BOT_TOKEN="8676658195:AAF0rRp21wAXr7GR_1zDU72YlHUuoiE_o28"
OWNER_ID="5303362533"
MONGO_URI="mongodb+srv://Raihanpaid90:<Raihanpaid90123456>@cluster0.a365mcd.mongodb.net/?appName=Cluster0"
"DB_NAME=default"