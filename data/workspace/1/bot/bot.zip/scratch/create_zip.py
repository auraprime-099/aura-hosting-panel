import os
import zipfile
import shutil

project_dir = r"c:\Users\BHARAT\Downloads\temp_mail_bot"
zip_path_downloads = r"c:\Users\BHARAT\Downloads\temp_mail_bot_project.zip"
zip_path_project = r"c:\Users\BHARAT\Downloads\temp_mail_bot\temp_mail_bot_project.zip"

files_to_include = [
    "bot.py",
    "config.py",
    "database.py",
    "extractor.py",
    "keyboards.py",
    "mail_service.py",
    "premium_emojis.py",
    "watcher.py",
    "requirements.txt",
    "README.md",
    ".gitignore",
    ".env",
    ".env.example"
]

print("Starting ZIP creation...")
with zipfile.ZipFile(zip_path_downloads, "w", zipfile.ZIP_DEFLATED) as zf:
    for f in files_to_include:
        full_p = os.path.join(project_dir, f)
        if os.path.exists(full_p):
            zf.write(full_p, arcname=os.path.join("temp_mail_bot", f))
            print(f"Added file: {f}")
    
    data_dir = os.path.join(project_dir, "data")
    if os.path.exists(data_dir):
        for root, _, files in os.walk(data_dir):
            for file in files:
                file_path = os.path.join(root, file)
                rel_path = os.path.relpath(file_path, project_dir)
                zf.write(file_path, arcname=os.path.join("temp_mail_bot", rel_path))
                print(f"Added data: {rel_path}")

shutil.copy2(zip_path_downloads, zip_path_project)

size_mb = os.path.getsize(zip_path_downloads) / (1024 * 1024)
print(f"SUCCESS: ZIP created! Size: {size_mb:.2f} MB")
print(f"Downloads location: {zip_path_downloads}")
print(f"Project folder location: {zip_path_project}")
