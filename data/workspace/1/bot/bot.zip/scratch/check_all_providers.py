import urllib.request
import json
import ssl

ctx = ssl._create_unverified_context()
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}

# 1. Dropmail.me
try:
    graphql_query = '{"query":"mutation { introduceSession { id, expiresAt, addresses { address } } }"}'
    req = urllib.request.Request(
        'https://dropmail.me/api/graphql/web-test-20180125',
        data=graphql_query.encode('utf-8'),
        headers={'Content-Type': 'application/json', **headers}
    )
    res = urllib.request.urlopen(req, context=ctx, timeout=5)
    data = json.loads(res.read())
    print('Dropmail:', data)
except Exception as e:
    print('Dropmail err:', e)

# 2. 1secmail
try:
    req = urllib.request.Request('https://www.1secmail.com/api/v1/?action=getDomainList', headers=headers)
    res = urllib.request.urlopen(req, context=ctx, timeout=5)
    print('1secmail:', res.read().decode())
except Exception as e:
    print('1secmail err:', e)

# 3. Guerrilla Mail
try:
    req = urllib.request.Request('https://api.guerrillamail.com/ajax.php?f=get_email_address', headers=headers)
    res = urllib.request.urlopen(req, context=ctx, timeout=5)
    print('Guerrilla:', res.read().decode())
except Exception as e:
    print('Guerrilla err:', e)

# 4. Inboxes.com
try:
    req = urllib.request.Request('https://inboxes.com/api/v2/domain', headers=headers)
    res = urllib.request.urlopen(req, context=ctx, timeout=5)
    print('Inboxes.com:', res.read().decode())
except Exception as e:
    print('Inboxes err:', e)

# 5. Mohmal
try:
    req = urllib.request.Request('https://www.mohmal.com/en/create', headers=headers)
    res = urllib.request.urlopen(req, context=ctx, timeout=5)
    print('Mohmal status:', res.status, res.headers.get('Set-Cookie'))
except Exception as e:
    print('Mohmal err:', e)
