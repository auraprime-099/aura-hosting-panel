import urllib.request
import re
import ssl

ctx = ssl._create_unverified_context()
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}

for query in ['"wallywatts.com"', '"wabblywabble.com"', '"barumart.com"', '"prorises.com"']:
    url = f'https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}'
    try:
        req = urllib.request.Request(url, headers=headers)
        html = urllib.request.urlopen(req, context=ctx, timeout=5).read().decode('utf-8', errors='ignore')
        matches = re.findall(r'<a class="result__snippet[^"]*"[^>]*>(.*?)</a>', html)
        print(f'=== Results for {query}: {len(matches)} ===')
        for m in matches[:3]:
            print(' ', re.sub(r'<[^>]+>', '', m))
    except Exception as e:
        print(f'Error for {query}:', e)
