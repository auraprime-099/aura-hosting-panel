import urllib.request
import json
import re
from bs4 import BeautifulSoup

req = urllib.request.Request('https://api.internal.temp-mail.io/api/v3/email/ycavx42929@olipii.com/messages', headers={'User-Agent': 'Mozilla/5.0'})
msgs = json.loads(urllib.request.urlopen(req).read())
msg = msgs[0]

subject = msg.get('subject', '')
text = msg.get('body_text', '')
html = msg.get('body_html', '')

print('Subject:', subject)

# Let's inspect where '90375' was found
print('Occurrences of 90375 in text:')
for m in re.finditer(r'.{0,30}90375.{0,30}', text):
    print(' ', repr(m.group(0)))

print('Occurrences of 90375 in html:')
for m in re.finditer(r'.{0,30}90375.{0,30}', html):
    print(' ', repr(m.group(0)))
