import asyncio
import os
import sys
import sqlite3

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
import database
import extractor
import keyboards
import mail_service
import premium_emojis
import watcher

async def run_full_scan():
    print("[1/6] Scanning Config & Environment...")
    assert config.BOT_TOKEN, "BOT_TOKEN is missing!"
    assert config.ADMIN_IDS, "ADMIN_IDS is empty!"
    print(f"  -> Config OK: Bot Token configured, {len(config.ADMIN_IDS)} Admin(s)")

    print("[2/6] Scanning Database Schema & Methods...")
    await database.init_db()
    # Test DB functions
    test_user_id = 999999999
    await database.get_or_create_user(test_user_id, "scan_test")
    await database.save_user_email(test_user_id, "scan_test@sharklasers.com", "fake_token", "fake_acc", "sharklasers.com", "scan_test", "guerrilla")
    u = await database.get_user(test_user_id)
    assert u is not None and u["email"] == "scan_test@sharklasers.com", "User insertion failed"
    
    await database.record_received_message("scan_msg_1", test_user_id, "TestService", "test@test.com", "Scan Subject", "123456", "https://example.com/verify")
    is_seen = await database.is_message_recorded("scan_msg_1")
    assert is_seen, "Message recording check failed"
    
    stats = await database.get_admin_stats()
    assert "total_users" in stats, "Admin stats failed"
    
    # Cleanup test user
    await database.delete_user_email(test_user_id)
    print("  -> Database OK: All CRUD, messaging, and stats functions working perfectly.")

    print("[3/6] Scanning Extractor (OTP, Magic Links, HTML Cleansing)...")
    # Test 1: Plain text OTP
    otp1 = extractor.extract_otp("Your code is 654321", "Please use code 654321 to login.")
    assert otp1 == "654321", f"Failed OTP1: {otp1}"

    # Test 2: OpenAI style HTML email with tables & menlo font
    openai_html = '<p>Enter this temporary verification code to continue:</p><p style="font-family:Menlo;font-size:24px;">\n987654\n</p>'
    otp2 = extractor.extract_otp("Your temporary ChatGPT verification code", openai_html, openai_html)
    assert otp2 == "987654", f"Failed OTP2: {otp2}"

    # Test 3: Koyeb / Supabase / Claude link
    link_html = '<p>Click <a href="https://auth.claude.ai/verify?token=abcd123">here</a> to sign in</p>'
    link = extractor.extract_verification_link(link_html, "")
    assert link == "https://auth.claude.ai/verify?token=abcd123", f"Failed link: {link}"

    # Test 4: Clean text content
    raw_html_center = '<center><table><tr><td>Hello <b>World</b></td></tr></table></center>'
    clean = extractor.clean_text_content(raw_html_center, raw_html_center)
    assert "Hello" in clean and "<center>" not in clean, "HTML tag stripping failed"
    print("  -> Extractor OK: OTP, Link, and Text normalization tests passed 100%.")

    print("[4/6] Scanning Keyboards & UI System...")
    kb_main_user = keyboards.get_main_keyboard(has_email=True, is_admin=False)
    kb_main_admin = keyboards.get_main_keyboard(has_email=True, is_admin=True)
    kb_mail_alert = keyboards.get_mail_alert_keyboard("msg_99", "https://verify.com")
    kb_full_mail = keyboards.get_full_mail_keyboard("msg_99", "https://verify.com")
    kb_admin = keyboards.get_admin_keyboard()
    assert kb_main_user and kb_main_admin and kb_mail_alert and kb_full_mail and kb_admin, "Keyboard creation failed"
    print("  -> Keyboards OK: All inline menus & interactive buttons verified.")

    print("[5/6] Scanning Mail Service Providers...")
    mgr = mail_service.UnifiedMailManager()
    
    # Check mailtm
    mailtm_doms = await mgr.mailtm.get_domains()
    print(f"  -> Mail.tm Domains Available: {mailtm_doms}")
    assert len(mailtm_doms) > 0, "No Mail.tm domains returned"

    # Check guerrilla
    assert len(mgr.guerrilla.DOMAINS) > 0, "Guerrilla domains missing"
    print(f"  -> Guerrilla Domains Configured: {mgr.guerrilla.DOMAINS}")

    print("[6/6] Scanning Bot Dispatcher & Handlers...")
    import bot
    dp = bot.dp
    print(f"  -> Handlers registered: {len(dp.message.handlers)} message handlers, {len(dp.callback_query.handlers)} callback query handlers.")
    assert len(dp.message.handlers) > 0, "No message handlers registered"
    assert len(dp.callback_query.handlers) > 0, "No callback query handlers registered"

    print("\n========================================================")
    print(">>> BOT FULL SYSTEM SCAN COMPLETED SUCCESSFULLY WITH ZERO ERRORS! <<<")
    print("========================================================")

if __name__ == "__main__":
    asyncio.run(run_full_scan())
