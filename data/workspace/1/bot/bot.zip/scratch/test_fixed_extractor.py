import re
from bs4 import BeautifulSoup
from typing import Optional, Dict, Any, List

VERIFY_KEYWORDS = [
    "verify", "verification", "confirm", "confirmation",
    "activate", "activation", "validate", "validation",
    "authenticate", "token", "signup", "sign-up", "register",
    "sign in", "signin", "log in", "login", "log-in", "magic-link",
    "magic link", "continue", "access", "get started", "join"
]

IGNORE_LINK_KEYWORDS = [
    "unsubscribe", "privacy", "terms", "opt-out", "help", "support",
    "preferences", "play.google.com", "apps.apple.com", "twitter.com",
    "facebook.com", "instagram.com", "linkedin.com"
]

def extract_otp(subject: str, text: str, html: str = "") -> Optional[str]:
    combined_content = f"{subject}\n{text}"
    
    # 1. Google-style or Prefix-style codes: G-123456, CODE-123456
    prefix_match = re.search(r'\b([A-Z]{1,4}-\d{4,8})\b', combined_content)
    if prefix_match:
        return prefix_match.group(1)

    # 2. Strict keyword-based OTP in Subject or Text
    keyword_patterns = [
        r'(?:verification|security|confirmation|login|otp|passcode|secret|access)?\s*(?:code|pin|otp|password)\s*(?:is|:|-)?\s*([0-9]{4,8})\b',
        r'\b([0-9]{4,8})\b\s*(?:is\s+your\s+(?:verification|security|confirmation|otp|code|login\s+code))',
        r'(?:enter|use)\s*(?:code|pin)?\s*([0-9]{4,8})\b',
        r'\bcode:\s*([0-9]{4,8})\b',
        r'(?:one-time|one\s+time)\s+(?:code|password|passcode)\s*(?:is|:|-)?\s*([0-9]{4,8})\b',
        r'\botp\s*(?:is|:|-)?\s*([0-9]{4,8})\b'
    ]

    for pattern in keyword_patterns:
        match = re.search(pattern, subject, re.IGNORECASE)
        if match:
            return match.group(1)

    for pattern in keyword_patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            # Avoid postal code / street numbers like "PMB 90375" or "PO Box"
            start_pos = match.start(1)
            preceding = text[max(0, start_pos - 20):start_pos].lower()
            if any(term in preceding for term in ["pmb", "box", "st,", "street", "suite", "apt"]):
                continue
            return match.group(1)

    # 3. Subject containing standalone 4-8 digit number IF subject has auth/verification words
    if any(k in subject.lower() for k in ["code", "otp", "verify", "verification", "confirm", "security", "use"]):
        subject_digits = re.search(r'\b([0-9]{4,8})\b', subject)
        if subject_digits:
            val = subject_digits.group(1)
            if not (len(val) == 4 and val.startswith("202")):
                return val

    # 4. Check HTML for highlighted code tag <code>123456</code> or <b>
    if html:
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup.find_all(["code", "b", "strong", "h1", "h2"]):
            tag_text = tag.get_text(strip=True)
            if re.fullmatch(r'[0-9]{4,8}', tag_text):
                if not (len(tag_text) == 4 and tag_text.startswith("202")):
                    # Check parent/surrounding text for code/otp keywords
                    parent_text = (tag.parent.get_text() if tag.parent else "").lower()
                    if any(kw in parent_text for kw in ["code", "otp", "pin", "verify", "security", "use"]):
                        return tag_text

    return None

def extract_verification_link(html: str, text: str) -> Optional[str]:
    # 1. Search HTML <a> tags
    if html:
        soup = BeautifulSoup(html, "html.parser")
        links = soup.find_all("a", href=True)
        
        # Priority 1: Anchor text contains verify / confirm / sign in / login / continue
        action_keywords = ["verify", "confirm", "activate", "sign in", "signin", "log in", "login", "get started", "complete registration", "continue", "magic link"]
        for a in links:
            href = a['href'].strip()
            anchor_text = a.get_text(strip=True).lower()
            
            if not href.startswith("http"):
                continue
            
            if any(k in anchor_text for k in action_keywords):
                if not any(ign in href.lower() for ign in IGNORE_LINK_KEYWORDS):
                    return href

        # Priority 2: href itself contains verification / magic link parameters
        link_url_keywords = ["magic-link", "magic_link", "token=", "verify", "verification", "confirm", "activate", "auth/verify", "login/magic"]
        for a in links:
            href = a['href'].strip()
            if not href.startswith("http"):
                continue
            lower_href = href.lower()
            if any(k in lower_href for k in link_url_keywords):
                if not any(ign in lower_href for ign in IGNORE_LINK_KEYWORDS):
                    return href

    # 2. Search plain text for URLs
    url_pattern = r'(https?://[^\s<>"\']+)'
    urls = re.findall(url_pattern, text)
    for url in urls:
        clean_url = url.rstrip(".,;)>]")
        lower_url = clean_url.lower()
        if any(k in lower_url for k in ["magic-link", "magic_link", "token=", "verify", "verification", "confirm", "activate", "signin", "login"]):
            if not any(ign in lower_url for ign in IGNORE_LINK_KEYWORDS):
                return clean_url

    return None

# Test on Claude message
import urllib.request, json
req = urllib.request.Request('https://api.internal.temp-mail.io/api/v3/email/ycavx42929@olipii.com/messages', headers={'User-Agent': 'Mozilla/5.0'})
msg = json.loads(urllib.request.urlopen(req).read())[0]

subject = msg['subject']
text = msg.get('body_text', '')
html = msg.get('body_html', '')

print("Testing on Claude message:")
print("Subject:", subject)
print("OTP:", extract_otp(subject, text, html))
print("Link:", extract_verification_link(html, text))
