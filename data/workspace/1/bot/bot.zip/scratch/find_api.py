import urllib.request
import re

req = urllib.request.Request('https://temp-mail.org/en/', headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
html = urllib.request.urlopen(req).read().decode('utf-8')

# Find JS files
scripts = re.findall(r'<script[^>]+src=[\'"]([^\'"]+)[\'"]', html)
print('Scripts:', scripts)

# Search for tokens or endpoints in html
for match in re.findall(r'(\b[a-zA-Z0-9_-]*(?:api|token|endpoint|mailbox|mail)[a-zA-Z0-9_-]*\b)', html, re.IGNORECASE):
    if len(match) > 6 and any(k in match.lower() for k in ['token', 'mailbox', 'api']):
        print('Token/API match:', match)
